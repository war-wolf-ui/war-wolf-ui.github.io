<template>
    <div class="rg-main">
        <Top :showBackIcon="true" v-mini-hide="true" />
        <div class="recharge">
            <div class="rc-mtitle">转入金额（元）</div>
            <div class="rc-mb " :class="{err:isShowErrFlag}">
                <div class="rc-msym">￥</div>
                <div class="rc-minp"><input placeholder="请输入充值金额" v-model="chargeNum" /></div>
            </div>

            <!-- 说明 -->
            <ul class="stored_explain">
                <h3>说明：</h3>
                <li>
                    <span>1.</span>
                    <span>储值卡用户购买商城制定品类的商品，购买商品时符合条件的订单可直接使用。</span>
                </li>
                <li>
                    <span>2.</span>
                    <span>如果您有任何疑问，可以直接联系商城人员进行咨询。</span>
                </li>
            </ul>
        </div>
        <div class="pay-position"><PayOrRecharge :chargeNum="chargeNum"></PayOrRecharge></div>
    </div>
</template>

<script type="text/javascript">
    import Top from "@/components/common/Top.vue";
    import PayOrRecharge from "@/components/common/recharge/PayOrRecharge.vue";
    import reg from "@/lib/reg.js"
    export default {
        name: "",
        data() {
            return {
                cardBalance: "", //储值卡余额
                chargeNum:'',
                isShowErrFlag:false,
            };
        },
        components: {
            Top,
            PayOrRecharge
        },
        computed: {},
        watch: {
            chargeNum(val){
                if(!reg.twoDecimal.test(val)){
                    this.isShowErrFlag = true;
                }else{
                    this.isShowErrFlag = false;
                }
            }
        },
        mounted() {

        },
        methods: {

        },
        destroyed(){
            sessionStorage.removeItem('wxH5Pay');
        }
    };
</script>

<style lang="less" scoped>
    .recharge{overflow: hidden;padding:10px;}
    .rc-mtitle{height: 20px;line-height: 20px;color:#333;font-size: 14px;}
    .rc-mb{height: auto;margin-top:10px;padding:8px 5px 5px 5px;border:1px solid #fff;}
    .rc-mb.err{border:1px solid red;border-radius: 8px;position: relative;}
    .rc-mb.err:before{
        content: '请输入正确的数字，最多2位小数！';
        position: absolute;
        top:45px;left:0px;font-size: 12px;color:red;
    }

    .rc-msym{width: 26px;height: 30px;line-height: 30px;text-align: center;font-size: 24px;font-weight: 600;color:#333;
        float:left;
    }
    .rc-minp{margin-left:26px;height: 30px;overflow: hidden;}
    .rc-minp input{border:none;background: none;height: 26px;width: 100%;
        line-height:26px;text-indent: 0px;color:#333;outline: none;font-size: 24px;}
    .stored_explain{overflow: hidden;margin-top:20px;}
    .stored_explain {
        h3 {
            padding: 12px 0;
            font-size: 14px;
        }

        li {
            display: flex;
            margin-bottom: 8px;
            font-size: 14px;
            color: #333;

            span:first-of-type {
                margin-right: 6px;
            }
        }
    }
    .rg-main{position: absolute;top:0px;left:0px;right:0px;bottom:0px;}
    .pay-position{position: absolute;bottom:0px;left:0px;right:0px;box-shadow: 0px 0px 10px #ccc;}

    .rc-minp input::-webkit-input-placeholder {font-size: 14px !important;color:#ccc !important;}
    .rc-minp input::-moz-placeholder {font-size: 14px !important;}
    .rc-minp input:-ms-input-placeholder {font-size: 14px !important;}
</style>