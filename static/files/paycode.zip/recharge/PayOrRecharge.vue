<template>
    <div class="pr_block">
        <div class="deb-title">
            <span class="deb-title-name">支付方式</span>
        </div>
        <ul class="deb-ul">
            <li class="deb-lis" :class="{active:payWayTabIndex==item}"
                v-for="(item,index) in payWayList" :key="index"
                @click="payWayCk(item)"
            >
                <div class="deb-lis-icon wx" :class="{wx:item == 1,zfb:item == 2}"></div>
                <div class="deb-lis-name">
                    <span v-show="item == 1">微信支付</span>
                    <span v-show="item == 2">支付宝支付</span>
                </div>
                <div class="deb-lis-subname"></div>
                <div class="deb-lis-radio "></div>
            </li>
        </ul>
        <div class="rgbtn" @click="rechargeMoney">确认充值</div>
    </div>
</template>

<script type="text/javascript">
    import reg from "@/lib/reg.js"
    export default {
        name: "",
        props: {
            chargeNum:{
                type:String,
                default:''
            }
        },
        data() {
            return {
                popupVisible:true,
                payWayList:[],
                payWayTabIndex:0,
                chargeMoney:0,//充值金额
                payChannel:'',//支付渠道
                openId:null,
            };
        },
        watch: {
            chargeNum(val){
                //console.log(val);
                this.chargeMoney = parseFloat(val);
            }
        },
        mounted() {
            this.getPayEnvironment();
        },
        methods: {
            //判断支付环境
            getPayEnvironment(){
                let self = this;
                //当前支付环境 1- 微信 2- 支付宝 3-微信小程序 4-PC端 5-app
                if (/MicroMessenger/.test(window.navigator.userAgent)) {
                    // 微信浏览器
                    this.$local.isWeChatMiniApp().then((res) => {
                        if (res) {
                            //小程序
                            console.log('小程序');

                            self.payChannel = 2;
                            self.getPayWay(3);

                            let code = self.$route.query.code;
                            //根据小程序传过来的code 获取openid
                            let paramMini = {
                                code:code,
                                payChannel:2,//1，微信公众号支付、2，微信小程序支付
                            };
                            self.$axios.post("/order/front/SellOrderFront/queryOpenIdByPayCode",paramMini).then((res)=>{
                                let d = res.data;
                                if(d.code == '0'){
                                    self.openId = d.data.openid;
                                }else{
                                    self.$toast({
                                        message:'获取openid失败!'
                                    });
                                }
                            }).catch((err)=>{
                                console.log(err);
                            });
                        } else {
                            //公众号支付
                            self.payChannel = 1;
                            self.getPayWay(1);
                        }
                    })
                }else{
                    if (this.$local.isInFlutter()) {    //APP环境
                        //console.log('APP环境');
                        self.getPayWay(null);
                    }else{
                        //console.log('非微信浏览器');
                        self.getPayWay(null);
                    }
                }
            },
            //获取支付方式 支付宝或者微信
            getPayWay(d){
                let self = this;
                let param = {
                    "payEnvironment": d,//	当前支付环境 null-手机浏览器 1- 微信 2- 支付宝 3-微信小程序 4-PC端 5-app
                };
                self.$axios.post('/order/front/orderInfo/memberCardPayType',param).then((res)=>{
                    let d = res.data;
                    // 支付类型：1,微信支付、2,支付宝支付、4,储值卡支付 6,线下付款 7,礼品卡
                    if(d.code == '0'){
                        self.payWayList = d.data.payMethod;
                        //console.log(self.payWayList);
                    }else{
                        self.$toast({
                            message: '查询支付方式失败！'
                        });
                    }

                }).catch((err)=>{
                    console.log(err);
                });
            },
            //支付方式点击
            payWayCk(item){
                let self = this;
                this.payWayTabIndex = item;
                //判断支付渠道
                if(this.payWayTabIndex == 1){   //微信支付方式
                    this.$local.isWeChatMiniApp().then((res) => {
                        if (res) {
                            self.payChannel = 2;
                        } else {
                            if (/MicroMessenger/.test(window.navigator.userAgent)) {
                                //公众号支付
                                self.payChannel = 1;
                            }else{
                                self.payChannel = 4;//微信H5
                            }
                        }
                    })
                }
                if(this.payWayTabIndex == 2){   //支付宝支付方式
                    self.payChannel = 8;//支付宝H5
                }
            },
            //确认充值点击------------------------------
            rechargeMoney(){
                let self = this;
                //判断充值金额是否正确
                if(this.chargeMoney == 0){
                    this.$toast({
                        message:'请输入正确的金额'
                    });
                    return;
                }
                if(!reg.twoDecimal.test(this.chargeMoney)){
                    this.$toast({
                        message:'请输入正确的金额'
                    });
                    return;
                }
                //选择支付类型
                if(this.payWayTabIndex == 0){
                    this.$toast({
                        message:'请选择支付方式！'
                    });
                    return;
                }

                //console.log('self.payChannel');
                //console.log(self.payChannel);
                //return;
                //判断如果是公众号支付
                if(self.payChannel === 1){
                    self.getAppId();
                }else{
                    let param = {
                        "openId": self.openId,              //微信公众号以及小程序必传
                        "payAmount": this.chargeMoney,     //支付金额
                        "payChannel": self.payChannel,    // 支付渠道 1，微信公众号支付、2，微信小程序支付、3，微信app支付、4，微信h5支付、5，微信主扫支付、6，现金支付、7，储值卡支付、8，支付宝h5支付、9，支付宝app支付、10，支付宝pc支付、11，支付宝主扫支付 12,线下付款 13,礼品卡, 14,微信PC支付；15：一卡通 16.储值卡扫码支付,17.钟山e卡支付,18.钟山e卡扫码支付
                        "payMethod": 1, //支付方式 1-在线支付 2-线下支付
                        "payType": this.payWayTabIndex,   //支付类型 1-微信 2-支付宝 3-现金 4-储值卡 5-分期付款 6-线下付款 7-礼品卡 8-一卡通 9-钟山e卡
                    };
                    self.$axios.post('/order/front/orderInfo/addCardAmount',param).then((res)=>{
                        let d = res.data;
                        if(d.code == '0'){
                            //如果是微信h5支付
                            if(self.payChannel === 4){
                                sessionStorage.setItem('wxH5Pay',true); //微信h5支付，给后退按钮点击时候用,防止再次跳到微信支付页
                                location.href = `${d.data.url}`;
                            }
                            //如果是支付宝h5支付
                            if(self.payChannel === 8){
                                const form = res.data.data.url;
                                const div = document.createElement("div");
                                div.id = "alipay-recharge";
                                div.innerHTML = form;
                                document.body.appendChild(div);
                                document.querySelector("#alipay-recharge").children[0].submit();
                            }

                            //微信小程序支付
                            if(self.payChannel === 2){
                                self.wxAppletsPay(JSON.parse(d.data.url));
                            }
                        }else{
                            self.$toast({
                                message:'支付失败！'
                            });
                        }
                    }).catch((err)=>{

                    });
                }
            },
            //微信H5公众号支付获取商户appid
            getAppId() {
                let param = {
                    payChannel: 1
                };
                this.$axios.post("/order/front/SellOrderFront/queryAppId",param).then(res => {
                    let d = res.data;
                    if(d.code == '0'){
                        let redirectURI = encodeURIComponent(`${location.origin}/wxPayRecharge?payAmount=${this.chargeMoney}`);
                        console.log(redirectURI);
                        //return;
                        window.location = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${d.data.appid}&redirect_uri=${redirectURI}&response_type=code&scope=snsapi_base&state=WXPaySTATE#wechat_redirect`;
                    }else{
                        this.$toast({
                            message:'获取appid失败'
                        });
                    }
                }).catch((err)=>{
                    console.log(err);
                });
            },
            //微信小程序支付
            wxAppletsPay(data) {
                //点击微信支付后，调取统一下单接口生成微信小程序支付需要的支付参数
                let payParam = {
                    appId: data.appId, //公众号名称，由商户传入
                    timeStamp: data.timeStamp, //时间戳，自1970年以来的秒数
                    nonceStr: data.nonceStr, //随机串
                    package: data.package,
                    signType: data.signType, //微信签名方式：
                    paySign: data.paySign //微信签名
                };
                // //定义path 与小程序的支付页面的路径相对应
                let path = `/pages/to-pay-recharge/index?payParam=${encodeURIComponent(JSON.stringify(payParam))}`;
                // //通过JSSDK的api跳转到指定的小程序页面
                wx.miniProgram.navigateTo({url: path});
            },
        }
    };
</script>

<style lang="less" scoped>
    .pr_block{background: #fff;}
    .deb-title{height: 48px;overflow: hidden;border-bottom: 1px solid #f2f2f2;line-height: 48px;}
    .deb-title-name{display: block;height: 48px;float:left;color:#333;font-size: 14px;font-weight: 600;
        margin-left:10px;
    }
    .deb-tclose{display: block;float:right;margin-right: 10px;color:#333;}
    .deb-ul{display: block;overflow: hidden;margin-top:10px;}
    .deb-lis{display: block;height: 50px;line-height: 50px;border:1px solid #e2e2e2;margin-left:10px;margin-right: 10px;
        margin-bottom: 10px;border-radius: 8px;}
    .deb-lis.active{border:1px solid #e93a3d;background: #f7f1f1;}
    .deb-lis-icon{width: 32px;height: 32px;float:left;border-radius: 5px;overflow: hidden;
        margin-left:9px;margin-top:9px;margin-right: 10px;
    }
    .deb-lis-icon.wx{background: url("../../../../static/img/icon/pay/icon-wx.png") no-repeat center;
        background-size: 100%;
    }
    .deb-lis-icon.zfb{background: url("../../../../static/img/icon/pay/icon-zfb.png") no-repeat center;
        background-size: 100%;
    }
    .deb-lis-name{font-size: 14px;color:#333;font-weight: 600;float:left;}
    .deb-lis-radio{width: 16px;height: 16px;float:right;background: url("../../../../static/img/icon/pay/radio.png") no-repeat center;
        background-size: 100%;margin-top:17px;margin-right: 10px;}

    .deb-lis.active .deb-lis-radio{background: url("../../../../static/img/icon/pay/radio-active.png") no-repeat center;
        background-size: 100%;}
    .rgbtn{color: #fff;
        background-color: red;
        text-align: center;
        font-size: 14px;
        height: 45px;
        line-height: 45px;
        font-weight: 600;margin:10px;border-radius:10px;}
</style>
