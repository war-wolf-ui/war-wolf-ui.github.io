<template>
    <div class="result_container">
        <div class="at_top" v-weixin-hide="true">
            <Top :showBackIcon="false" title="确认充值"></Top>
        </div>
    </div>
</template>

<script type="text/javascript">
    import Top from "@/components/common/Top.vue";
    import {Toast, Indicator} from "mint-ui";
    import wx from "weixin-jsapi";

    export default {
        name: "",
        data() {
            return {};
        },

        components: {
            Top
        },

        computed: {},

        watch: {},
        async created() {
            let url = decodeURI(location.search); //获取url中"?"符后的字串
            let params = new Object();

            // 获取微信重定向URL的code
            if (url.indexOf("?") != -1) {
                let str = url.substr(1);
                let strs = str.split("&");
                for (let i = 0; i < strs.length; i++) {
                    params[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
                }
                this.getAppidCode(params);
            }
        },

        methods: {
            /**
             * 微信H5公众号支付 根据code 获取openid
             */
            getAppidCode(params) {
                this.$axios
                    .post("/order/front/SellOrderFront/queryOpenId", {
                        code: params.code,
                        payChannel:1,//1，微信公众号支付、2，微信小程序支付
                    })
                    .then(res => {
                        let _params = Object.assign(params, {openid: res.data.data.openid});
                        if (res.data.code == "0") {
                            this.payOnlineSaleOrder(_params);
                        } else {
                            Toast({
                                message: res.data.message
                            });
                        }
                    });
            },
            // 线上订单付款
            payOnlineSaleOrder(params) {
                let self = this;
                let param = {
                    "openId": params.openid,//微信公众号以及小程序必传
                    "payAmount": params.payAmount,     //支付金额
                    "payChannel": 1,    // self.payChannel  支付渠道 1，微信公众号支付、2，微信小程序支付、3，微信app支付、4，微信h5支付、5，微信主扫支付、6，现金支付、7，储值卡支付、8，支付宝h5支付、9，支付宝app支付、10，支付宝pc支付、11，支付宝主扫支付 12,线下付款 13,礼品卡, 14,微信PC支付；15：一卡通 16.储值卡扫码支付,17.钟山e卡支付,18.钟山e卡扫码支付
                    "payMethod": 1, //支付方式 1-在线支付 2-线下支付
                    "payType": 1,   //支付类型 1-微信 2-支付宝 3-现金 4-储值卡 5-分期付款 6-线下付款 7-礼品卡 8-一卡通 9-钟山e卡
                };
                self.$axios.post('/order/front/orderInfo/addCardAmount',param).then((res)=>{
                    let d = res.data;
                    if(d.code == '0'){
                        self.getSignature(JSON.parse(res.data.data.url));
                        //self.wxPayDialog(self.$local.paramsFormat(d.data.url));
                    }else{
                        self.$toast({
                            message:'支付失败！'
                        });
                    }
                }).catch((err)=>{

                });
            },

            //可以优化掉
            getSignature(data) {
                let param = {
                    url: location.href
                };
                this.$axios
                    .post("/base/front/weChatParam/getWeChatJsApiConfigRequestDTO", param)
                    .then(res => {
                        //console.log(res.data)
                        if (res.data.code == '0') {
                            wx.config({
                                beta: true, // 必须这么写，否则wx.invoke调用形式的jsapi会有问题
                                debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来
                                appId: res.data.data.appId, // 必填，企业微信的corpID
                                timestamp: res.data.data.timestamp, // 必填，生成签名的时间戳
                                nonceStr: res.data.data.nonceStr, // 必填，生成签名的随机串 必填，生成签名的随机串
                                signature: res.data.data.sign, // 必填，签名
                                jsApiList: ["getBrandWCPayRequest"]
                            });
                            this.wxPayDialog(data);
                        }
                    });
            },

            /**
             * 唤起微信支付弹框
             */
            wxPayDialog(data) {
                let _this = this;
                //H5网页支付例子
                wx.chooseWXPay({
                    timestamp: data.timeStamp, // 支付签名时间戳，注意微信jssdk中的所有使用timestamp字段均为小写。但最新版的支付后台生成签名使用的timeStamp字段名需大写其中的S字符
                    nonceStr: data.nonceStr, // 支付签名随机串，不长于 32 位
                    package: data.package, // 统一支付接口返回的prepay_id参数值，提交格式如：prepay_id=\*\*\*）
                    signType: data.signType, // 微信支付V3的传入RSA,微信支付V2的传入格式与V2统一下单的签名格式保持一致
                    paySign: data.paySign, // 支付签名
                    success: function (res) {
                        // 支付成功后的回调函数
                        if (res.err_msg == "get_brand_wcpay_request:ok") {
                            location.href = `${location.origin}/storedValueCard`

                        } else {
                            location.href = `${location.origin}/storedValueCard?status=err`
                        }
                    }
                });
            }
        },

        mounted() {
        },
    };
</script>

<style lang="less" scoped>
</style>